Bilal Mahmood, Calvin Medley, and Matina Shrestha
COSC 5360 - Group Project (Spring 2021)

There are no real special instruction as far as compiling code and running it. All you need to do is run it. There is a database creation option that runs at the very beginning of the code in case it does not see the database in the filepath expected. You do not have to execute this option and can bypass it by selecting "n". However, it will continue to ask until it sees a pair of database files so it knows what to pull form/add to. There is also a pair of files included (VoterList and CandidateList) that are the requested databases with some test information already provided. Using the "create" option in the code creates blank databases.

For using the "Admin" side of commands, the registered password (as can be seen in the code) is "Admin@1234*" no quotes.

The videos were too large to load into Blackboard, so the links will be submitted in the video submission section on BB. They are also listed here:

Admin-Side Testing
https://youtu.be/mcwW9Xo6gi8

User-Side Testing
https://youtu.be/rcrl5YMALKg